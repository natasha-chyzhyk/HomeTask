package com.natasha.sourceit.task_jdbc.not_abstr.dao;

import com.natasha.sourceit.task_jdbc.dao.abstr.AccountsSubjectsDAO;
import com.natasha.sourceit.task_jdbc.dao.abstr.SubjectDAO;
import com.natasha.sourceit.task_jdbc.model.AccountDbModel;
import com.natasha.sourceit.task_jdbc.model.ClassDbModel;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Stas on 17.01.2017.
 */
public class AccountDAO_NOT_ABSTR {
    private static final String TABLE_NAME = "vasya.account";

    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_AGE = "age";
    private static final String COLUMN_CLASS_ID = "class_id";

    private static final String SQL_SELECT_TEMPLATE = "SELECT * FROM %s WHERE %s;";

    private Connection dbConn;

    public AccountDAO_NOT_ABSTR(Connection dbConn) {
        this.dbConn = dbConn;
    }

    public AccountDbModel getModelById(long id) throws SQLException {

        String where = getWhereForEquals(COLUMN_ID, id);
        String sql = String.format(SQL_SELECT_TEMPLATE, TABLE_NAME, where);
        ResultSet rs = dbConn.createStatement().executeQuery(sql);

        return (rs.first()) ? getModelFromResultSet(rs) : null;
    }

    public List<AccountDbModel> getModelsByIds(List<Long> ids) throws SQLException {

        String where = getWhereForIN(COLUMN_ID, ids);
        String sql = String.format(SQL_SELECT_TEMPLATE, TABLE_NAME, where);
        ResultSet rs = dbConn.createStatement().executeQuery(sql);

        return buildAllModelsFromResultSet(rs);
    }

    public List<AccountDbModel> getAccountsForClass(ClassDbModel classDbModel) throws SQLException {
        String where = getWhereForEquals(COLUMN_CLASS_ID, classDbModel.getId());
        String sql = String.format(SQL_SELECT_TEMPLATE, TABLE_NAME, where);
        ResultSet rs = dbConn.createStatement().executeQuery(sql);

        List<AccountDbModel> models = new ArrayList<>();
        if (rs.first()) {
            do {
                AccountDbModel model = getModelFromResultSet(rs);
                model.setClass_id(classDbModel.getId());
                models.add(model);
            } while (rs.next());
        }
        return models;
    }

    private String getWhereForEquals(String colName, long value) {
        return String.format("(%s = %d)", colName, value);
    }

    private String getWhereForIN(String colName, List<Long> ids) {
        StringBuilder sb = new StringBuilder("("+colName+" IN (");
        for (int i=0; i<ids.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(ids.get(i));
        }
        sb.append("))");
        return sb.toString();
    }

    private AccountDbModel getModelFromResultSet(ResultSet rs) throws SQLException {
        AccountDbModel account = new AccountDbModel(rs.getInt(rs.findColumn(COLUMN_ID)));
        account.setName(rs.getString(rs.findColumn(COLUMN_NAME)));
        account.setAge(rs.getInt(rs.findColumn(COLUMN_AGE)));

        AccountsSubjectsDAO accountsSubjectsDAO = new AccountsSubjectsDAO(dbConn);
        List<Integer> subjectIds = accountsSubjectsDAO.getSubjectIdsForAccount(account.getId());

        SubjectDAO subjectDao = new SubjectDAO(dbConn);
        account.setSubject(subjectDao.getModelsByIds(subjectIds));

        return account;
    }


    private List<AccountDbModel> buildAllModelsFromResultSet(ResultSet rs) throws SQLException {
        List<AccountDbModel> models = new ArrayList<>();
        if (rs.first()) {
            do {
                models.add(getModelFromResultSet(rs));
            } while (rs.next());
        }
        return models;
    }
}
