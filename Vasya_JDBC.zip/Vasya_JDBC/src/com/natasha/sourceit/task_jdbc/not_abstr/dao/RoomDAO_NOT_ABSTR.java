package com.natasha.sourceit.task_jdbc.not_abstr.dao;

import com.natasha.sourceit.task_jdbc.dao.abstr.ClassDAO;
import com.natasha.sourceit.task_jdbc.dao.abstr.SubjectDAO;
import com.natasha.sourceit.task_jdbc.model.RoomDbModel;
import com.natasha.sourceit.task_jdbc.model.SchoolDbModel;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Stas on 17.01.2017.
 */
public class RoomDAO_NOT_ABSTR {
    private static final String TABLE_NAME = "subject.room";

    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NUMBER = "number";
    private static final String COLUMN_FLOOR = "floor";
    private static final String COLUMN_AMOUNT = "amount";
    private static final String COLUMN_SCHOOL_ID = "school_id";

    private static final String SQL_SELECT_TEMPLATE = "SELECT * FROM %s WHERE %s;";

    private Connection dbConn;

    public RoomDAO_NOT_ABSTR(Connection dbConn) {
        this.dbConn = dbConn;
    }

    public RoomDbModel getModelById(int id) throws SQLException {
        String where = getWhereForEquals(COLUMN_ID, id);
        String sql = String.format(SQL_SELECT_TEMPLATE, TABLE_NAME, where);
        ResultSet rs = dbConn.createStatement().executeQuery(sql);

        return (rs.first()) ? getModelFromResultSet(rs) : null;
    }

    public List<RoomDbModel> getModelsByIds(List<Integer> ids) throws SQLException {
        String where = getWhereForIN(COLUMN_ID, ids);
        String sql = String.format(SQL_SELECT_TEMPLATE, TABLE_NAME, where);
        ResultSet rs = dbConn.createStatement().executeQuery(sql);

        return buildAllModelsFromResultSet(rs);
    }

    public List<RoomDbModel> getRoomsRorSchool(SchoolDbModel school) throws SQLException {
        String where = getWhereForEquals(COLUMN_SCHOOL_ID, school.getId());
        String sql = String.format(SQL_SELECT_TEMPLATE, TABLE_NAME, where);
        ResultSet rs = dbConn.createStatement().executeQuery(sql);

        List<RoomDbModel> models = new ArrayList<>();
        if (rs.first()) {
            do {
                RoomDbModel model = getModelFromResultSet(rs);
                model.setSchool_id(school.getId());
                models.add(model);
            } while (rs.next());
        }
        return models;
    }

    private String getWhereForEquals(String colName, int value) {
        return String.format("(%s = %d)", colName, value);
    }

    private String getWhereForIN(String colName, List<Integer> ids) {
        StringBuilder sb = new StringBuilder("("+colName+" IN (");
        for (int i=0; i<ids.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(ids.get(i));
        }
        sb.append("))");
        return sb.toString();
    }

    private RoomDbModel getModelFromResultSet(ResultSet rs) throws SQLException {
        RoomDbModel room = new RoomDbModel(rs.getInt(rs.findColumn(COLUMN_ID)));
        room.setNumber(rs.getString(rs.findColumn(COLUMN_NUMBER)));
        room.setFloor(rs.getInt(rs.findColumn(COLUMN_FLOOR)));
        room.setAmount(rs.getInt(rs.findColumn(COLUMN_AMOUNT)));

        com.natasha.sourceit.task_jdbc.dao.abstr.ClassDAO classDao = new ClassDAO(dbConn);
        room.setClassDbModels(classDao.getClassesForRoom(room));

        SubjectDAO subDAO = new SubjectDAO(dbConn);
        room.setSubject(subDAO.getSubjectForRoom(room));

        return room;
    }


    private List<RoomDbModel> buildAllModelsFromResultSet(ResultSet rs) throws SQLException {
        List<RoomDbModel> models = new ArrayList<>();
        if (rs.first()) {
            do {
                models.add(getModelFromResultSet(rs));
            } while (rs.next());
        }
        return models;
    }
}
