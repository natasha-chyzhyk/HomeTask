package com.natasha.sourceit.task_jdbc.not_abstr.dao;

import com.natasha.sourceit.task_jdbc.dao.abstr.RoomDAO;
import com.natasha.sourceit.task_jdbc.model.SchoolDbModel;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Stas on 17.01.2017.
 */
public class SchoolDAO_NOT_ABSTR {
    private static final String TABLE_NAME = "vasya.school";

    private static final String COLUMN_ID = "id";
    private static final String COLUMN_ADDRESS = "address";
    private static final String COLUMN_NUMBER = "number";
    private static final String COLUMN_FLOORS = "floors";

    private static final String SQL_SELECT_TEMPLATE = "SELECT * FROM %s WHERE %s;";
    private static final String SQL_SELECT_ALL_TEMPLATE = "SELECT * FROM %s;";

    private Connection dbConn;

    public SchoolDAO_NOT_ABSTR(Connection dbConn) {
        this.dbConn = dbConn;
    }

    public SchoolDbModel getModelById(int id) throws SQLException {
        String where = getWhereForEquals(COLUMN_ID, id);
        String sql = String.format(SQL_SELECT_TEMPLATE, TABLE_NAME, where);
        ResultSet rs = dbConn.createStatement().executeQuery(sql);

        return (rs.first()) ? getModelFromResultSet(rs) : null;
    }

    public List<SchoolDbModel> getModelsByIds(List<Integer> ids) throws SQLException {
        String where = getWhereForIN(COLUMN_ID, ids);
        String sql = String.format(SQL_SELECT_TEMPLATE, TABLE_NAME, where);
        ResultSet rs = dbConn.createStatement().executeQuery(sql);

        return buildAllModelsFromResultSet(rs);
    }

    private String getWhereForEquals(String colName, int value) {
        return String.format("(%s = %d)", colName, value);
    }

    private String getWhereForIN(String colName, List<Integer> ids) {
        StringBuilder sb = new StringBuilder("("+colName+" IN (");
        for (int i=0; i<ids.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(ids.get(i));
        }
        sb.append("))");
        return sb.toString();
    }

    private SchoolDbModel getModelFromResultSet(ResultSet rs) throws SQLException {
        SchoolDbModel school = new SchoolDbModel(rs.getInt(rs.findColumn(COLUMN_ID)));
        school.setAddress(rs.getString(rs.findColumn(COLUMN_ADDRESS)));
        school.setNumber(rs.getString(rs.findColumn(COLUMN_NUMBER)));
        school.setFloors(rs.getInt(rs.findColumn(COLUMN_FLOORS)));

        com.natasha.sourceit.task_jdbc.dao.abstr.RoomDAO room = new RoomDAO(dbConn);
        school.setRooms(room.getRoomsRorSchool(school));

        return school;
    }

    public List<SchoolDbModel> getAllModels() throws SQLException {
        String sql = String.format(SQL_SELECT_ALL_TEMPLATE, TABLE_NAME);
        ResultSet rs = dbConn.createStatement().executeQuery(sql);

        return buildAllModelsFromResultSet(rs);
    }

    private List<SchoolDbModel> buildAllModelsFromResultSet(ResultSet rs) throws SQLException {
        List<SchoolDbModel> models = new ArrayList<>();
        if (rs.first()) {
            do {
                models.add(getModelFromResultSet(rs));
            } while (rs.next());
        }
        return models;
    }
}
