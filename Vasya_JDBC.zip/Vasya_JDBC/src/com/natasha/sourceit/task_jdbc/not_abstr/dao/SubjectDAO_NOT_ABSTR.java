package com.natasha.sourceit.task_jdbc.not_abstr.dao;

import com.natasha.sourceit.task_jdbc.model.RoomDbModel;
import com.natasha.sourceit.task_jdbc.model.SubjectDbModel;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Stas on 17.01.2017.
 */
public class SubjectDAO_NOT_ABSTR {
    private static final String TABLE_NAME = "vasya.subject";

    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_ROOM_ID = "room_id";

    private static final String SQL_SELECT_TEMPLATE = "SELECT * FROM %s WHERE %s;";

    private Connection dbConn;

    public SubjectDAO_NOT_ABSTR(Connection dbConn) {
        this.dbConn = dbConn;
    }

    public SubjectDbModel getModelById(int id) throws SQLException {
        String where = getWhereForEquals(COLUMN_ID, id);
        String sql = String.format(SQL_SELECT_TEMPLATE, TABLE_NAME, where);
        ResultSet rs = dbConn.createStatement().executeQuery(sql);

        return (rs.first()) ? getModelFromResultSet(rs) : null;
    }

    public List<SubjectDbModel> getModelsByIds(List<Integer> ids) throws SQLException {
        String where = getWhereForIN(COLUMN_ID, ids);
        String sql = String.format(SQL_SELECT_TEMPLATE, TABLE_NAME, where);
        ResultSet rs = dbConn.createStatement().executeQuery(sql);

        return buildAllModelsFromResultSet(rs);
    }

    public List<SubjectDbModel> getSubjectForRoom(RoomDbModel room) throws SQLException {
        String where = getWhereForEquals(COLUMN_ROOM_ID, room.getId());
        String sql = String.format(SQL_SELECT_TEMPLATE, TABLE_NAME, where);
        ResultSet rs = dbConn.createStatement().executeQuery(sql);

        List<SubjectDbModel> models = new ArrayList<>();
        if (rs.first()) {
            do {
                SubjectDbModel subjectDbModel = getModelFromResultSet(rs);
                subjectDbModel.setRoom_id(room.getId());
                models.add(subjectDbModel);
            } while (rs.next());
        }
        return models;
    }
    private String getWhereForEquals(String colName, int value) {
        return String.format("(%s = %d)", colName, value);
    }

    private String getWhereForIN(String colName, List<Integer> ids) {
        StringBuilder sb = new StringBuilder("("+colName+" IN (");
        for (int i=0; i<ids.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(ids.get(i));
        }
        sb.append("))");
        return sb.toString();
    }

    private SubjectDbModel getModelFromResultSet(ResultSet rs) throws SQLException {
        SubjectDbModel subject = new SubjectDbModel(rs.getInt(rs.findColumn(COLUMN_ID)));
        subject.setName(rs.getString(rs.findColumn(COLUMN_NAME)));

        return subject;
    }


    private List<SubjectDbModel> buildAllModelsFromResultSet(ResultSet rs) throws SQLException {
        List<SubjectDbModel> models = new ArrayList<>();
        if (rs.first()) {
            do {
                models.add(getModelFromResultSet(rs));
            } while (rs.next());
        }
        return models;
    }

}
