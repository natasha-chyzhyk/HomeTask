package com.natasha.sourceit.task_jdbc.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Stas on 17.01.2017.
 */
public class SchoolDbModel extends BaseDbModel {

    private String address;
    private String number;
    private int floors;
    private final List<RoomDbModel> rooms;

    public SchoolDbModel(int id) {
        super(id);
        rooms = new ArrayList<>();
    }

    @Override
    public String toString() {
        return String.format("School:{id=%d, address=%s, number=%s, floors=%d}", getId(), address, number, floors);
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public int getFloors() {
        return floors;
    }

    public void setFloors(int floors) {
        this.floors = floors;
    }

    public List<RoomDbModel> getRooms() {
        return rooms;
    }

    public void setRooms(List<RoomDbModel> rooms) {
        this.rooms.clear();
        if (rooms != null) {
            this.rooms.addAll(rooms);
        }
    }
}
