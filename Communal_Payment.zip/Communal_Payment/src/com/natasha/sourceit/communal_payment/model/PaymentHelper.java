package com.natasha.sourceit.communal_payment.model;

/**
 * MArker interface for entries which can accept and process payments
 */
public interface PaymentHelper {
}
