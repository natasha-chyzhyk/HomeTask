package com.natasha.sourceit.communal_payment.model;

/**
 * Created by Stas on 29.01.2017.
 */
public interface IAccountId {
    long flatId();
    long supplyerId();
}
