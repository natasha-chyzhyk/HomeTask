package com.natasha.sourceit.communal_payment.model;


public enum CalculationFormulaType {
    LICENSE_FEE, CALCULATION, COMBINATION;
}
