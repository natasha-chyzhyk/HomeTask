package com.natasha.sourceit.communal_payment;

import com.natasha.sourceit.communal_payment.model.impl.HumanDbModel;
import com.natasha.sourceit.communal_payment.storage.access.DbConnectionHolder;
import com.natasha.sourceit.communal_payment.storage.dao.BuildingDAO;

import java.sql.Connection;

public class Main {

    public static void main(String[] args) throws Exception {
	// write your code here

        Connection conn = DbConnectionHolder.getConnection();
        new BuildingDAO(conn).selectAllModels();

    }
}
