package com.natasha.sourceit.task9.action;

/**
 * Created by Stas on 30.11.2016.
 */
public class RangeAttack extends BaseAttack {
    public RangeAttack(com.natasha.sourceit.task9.Character targetCharacter, int attackPower) {
        super(targetCharacter, attackPower);
    }

    @Override
    public AttackType getAttackType() {
        return AttackType.RANGE;
    }
}
