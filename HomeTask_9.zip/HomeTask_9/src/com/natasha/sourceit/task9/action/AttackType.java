package com.natasha.sourceit.task9.action;

/**
 * Created by Stas on 30.11.2016.
 */
public enum  AttackType {
    RANGE, MAGIC, MALE

}
