package com.natasha.sourceit.task9.action;

import com.natasha.sourceit.task9.Character;

/**
 * Created by Stas on 30.11.2016.
 */
public interface CharacterAction {
    void doAction();
    Character getActionTarget();
}
